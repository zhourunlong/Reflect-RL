***************************************
Getting started
***************************************

Assuming you have Python already, follow the guidelines below to get started with Arrow.

.. include:: ../README.rst
  :start-after: Quick Start
  :end-before: end-inclusion-marker-do-not-remove
